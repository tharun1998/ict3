import React,{useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import {Link, NavLink, useNavigate} from 'react-router-dom'
import { userlogout } from '../../Actions/UserAction/UserActions';

import './index.css'
import Searchbox from './Searchbox';
const Header = () => {
  const dispatch=useDispatch()
  const userdata=useSelector(state=>state.userdata);
  const{userdetails}=userdata;
  const navigate=useNavigate()
    const [show,setShow]=useState(false);
 
  const toggle=()=>{

    return setShow(!show);
  }
  const logout=()=>{
dispatch(userlogout());


navigate("/home");
  }
 
  return (
    <div className='container'>

      <div className="navbar">

        <div className="logo" style={{cursor:"pointer"}}>


        {/* <div className="bag" style={{cursor:"pointer"}} onClick={changeroute}>
          <i className='bx bx-shopping-bag ' style={{color:"black",fontSize:"22px",marginRight:"50px"}}>
          </i>
         {console.log(userdata.userdetails)}
          </div>   */}

        </div>

        <div className={show ? "links active" : "links"}>
     
        {userdata.userdetails  ?(
          <>

                   <Link to="/home"> Home</Link>

                  <Link onClick={()=>toggle()} to="/recommendation">Recommendation</Link>

 <Link onClick={()=>toggle()}to="/profile"> my fav</Link>
 <Link className="logo" onClick={()=>toggle()} to="/addbook" > Add book</Link>

<button  className="logout" onClick={logout} >Logout</button>

<Searchbox/>

            </>
          
        ):(
 <Link onClick={()=>toggle()}to="/"> Signin <i className='bx bx-user ' ></i></Link>

          )}
              

        </div>
        <div className={show ?'bars-button active' : 'bars-button'} onClick={()=>toggle()}>
        <span></span>
        <span></span>
        <span></span>
        </div>
      </div>
 
    </div>
  )
}

export default Header