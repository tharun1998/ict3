import axios from 'axios'
import React, { useState,useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { NavLink } from 'react-router-dom'
import { creatingorder } from '../Actions/favlistactions/favlistactions'

const Card = ({words=''}) => {
    const [data,setData]=useState([])
    useEffect(() => {
        axios.get(`http://localhost:8001/products/?words=${words}`)
        .then(res=>setData(res.data))
    }, [words]);
 
const dispatch=useDispatch()
    const orderdata=useSelector((state)=>state.orderdata);
    const orderdetailsdata=useSelector((state)=>state.orderdetailsdata);
    const favhandler=(book)=>{
const{Name,Author,Description,Category,Language}=book;
     dispatch(creatingorder({
          Favbook:{Name,Author,Description,Category,Language}}))}
  return (
    <div>
        <div className="container">

        <div className="row">
{data.map((singlebook)=>(
            <div className="col-4">



<div className="card">
  <img src={singlebook.Img} className="card-img-top img-fluid" alt="..."/>
  <div className="card-body">
    <h5 className="card-title">{singlebook.Name}</h5>
    <p className="card-text">By{singlebook.Author}</p>
<p>description:{singlebook.Description}</p>   
<p>category:{singlebook.Category}</p>
<NavLink to={`/products/${singlebook._id}`} className="btn btn-primary mx-3">Open</NavLink>
<button className='btn btn-success mx-3'onClick={()=>favhandler(singlebook)}>add to Favlist</button> 
 </div>
</div>

</div>

))}
        </div>
        </div>

</div>
  )
}

export default Card