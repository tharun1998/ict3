export const RecommendationDataReducer=(state={},action)=>{
    switch(action.type){
        case'RECOMMENDATION_SUCCESS':
        return{
            recommendation:action.payload,
            success:true
        }
        case'RECOMMENDATION_FAILED':
        return{
            error:action.payload
        }
        default:
            return state;
    }
    }

    export const RecommendationListDataReducer=(state={recommended:[]},action)=>{
        switch(action.type){
            case'RECOMMENDATION_LIST_SUCCESS':
            return{
    recommended:action.payload,
                success:true
            }
            case'RECOMMENDATION_LIST_FAILED':
            return{
                error:action.payload
            }
          
            default:
                return state;
        }
        }
    
    