import logo from './logo.svg';
import './App.css';
import Header from './Components/Header';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Signin from './Pages/Signin/Signin';
import Registration from './Pages/Registration/Registration';
import { useDispatch } from 'react-redux';
import Home from './Pages/Home/Home';
import SingleCard from './Components/SingleCard';
import Profile from './Profile';
import Recommendation from './Pages/Recommendation/Recommendation';
import AddBook from './Pages/AddBook';

function App() {
 
  


  return (
    <>
    <div className='container1'style={{minHeight:"90vh"}} >
    
    <Router>
<Header/>
      <Routes>

     <Route path='/home' element={<Home/>}/>
     <Route path="/home/:words"  element={<Home/>}/>
<Route path="/recommendation" element={<Recommendation/>}/>
<Route path="/addbook" element={<AddBook/>}/>

     <Route path="/" element={<Signin/>}/>
     <Route path="/profile" element={<Profile/>}/>
     <Route path="/products/:id" element={<SingleCard/>}/>
        

<Route path="/register" element={<Registration/>}/>

      

      </Routes>
    </Router>

    </div>

</>
  );
}

export default App;
