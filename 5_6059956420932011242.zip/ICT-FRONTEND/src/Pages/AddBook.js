import axios from 'axios';
import React,{useState} from 'react'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const AddBook = () => {
    const[name,setName]=useState("");
    const[description,setDescription]=useState("");
    const[author,setAuthor]=useState("");
    const[language,setLanguage]=useState("");
    const[category,setCategory]=useState("")
const handlesubmit=(e)=>{
    e.preventDefault();
    axios.post("http://localhost:8001/products/newbook",{
        Name:name,
        Author:author,
        Description:description,
        Category:category,
        Language:language
    })
    toast.success('book added')
    setName("")
    setAuthor("")
    setDescription("")
    setCategory("")
    setLanguage("")
}
  return (
    <>
    <ToastContainer/>
        <h1>Add book</h1>
        <div div className="container">

     
			<form  onSubmit={(e)=>handlesubmit(e)}>
      <div class="input-group input-group-sm mb-3">

					<input type="text" placeholder=" Name"  class="form-control" value={name} onChange={(e)=>setName(e.target.value)} required/>
             </div>      
             <div class="input-group input-group-sm mb-3">
 
					<input type="text" placeholder="author"  class="form-control" value={author} onChange={(e)=>setAuthor(e.target.value)} required/>
          
          </div>      
<div class="input-group input-group-sm mb-3">
       
					<input type="text"  placeholder="description"  class="form-control" value={description} onChange={(e)=>setDescription(e.target.value)} minLength="6" required/>
                    {/* value={Password} */}             </div>      

                    <div class="input-group input-group-sm mb-3">

				<input type="text"   class="form-control" placeholder="catergory"value={category} onChange={(e)=>setCategory(e.target.value)} minLength="6" required/>
                             </div>      
                             <div class="input-group input-group-sm mb-3">

<input type="text"   class="form-control" value={language} onChange={(e)=>setLanguage(e.target.value)}placeholder="language" required/>
             </div>  
				<button className="btn btn-primary mb-3">
					<span className="button__text"  >  Add book</span>
				</button>		
		
			</form>
            </div>
            </>

      )
}

export default AddBook