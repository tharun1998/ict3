import axios from "axios";

export const bookreview=(productId,review)=>async(dispatch,getState)=>{
    try{
        const {userdata:{userdetails}}=getState()
        const config={
headers:{
Authorization:`Bearer ${userdetails.token}`
}
        }
   const data=  await axios.post(`http://localhost:8001/products/review/${productId}`,review,config);

        dispatch({
           type:'REVIEW_SUCCESS',
           payload:data
        })
       
    //     localStorage.removeItem("cartitems")
    //     toast.success("order placed")


    }
    catch(error){
dispatch({type:'REVIEW_FAIL',
        payload:error.response && 
        error.response.data.message ? error.response.data.message:error.message})

    }
}