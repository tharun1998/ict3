import { composeWithDevTools } from "@redux-devtools/extension";
import axios from "axios";
import { applyMiddleware, combineReducers, createStore } from "redux";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export const creatingorder=(Favbook)=>async(dispatch,getState)=>{
        try{
            const {userdata:{userdetails}}=getState()
    console.log(userdetails.token);
    console.log(Favbook);
            const config={
    headers:{
    "Content-Type":"application/json",
    Authorization:`Bearer ${userdetails.token}`
    }
            }
            const data= await axios.post("http://localhost:8001/favlist",Favbook,config)
    console.log(data);
    
            dispatch({
               type:'ORDER_SUCCESS',
               payload:data
    
            })
        //     dispatch({
        //         type:'MY_ORDER_SUCCESS',
        //         payload:data
     
        //      })
    

    
        }
        catch(error){
    dispatch({type:'ORDER_FAILED',
            payload:error.response && 
            error.response.data.message ? error.response.data.message:error.message})
    
        }
    }

  
    export const myfav=()=>async(dispatch,getState)=>{
        try{
            const {userdata:{userdetails}}=getState()
            const config={
    headers:{
    Authorization:`Bearer ${userdetails.token}`
    }
            }
            const data= await axios.get(`http://localhost:8001/favlist/myfav`,config);
    console.log("my fav books",data);
    
            dispatch({
               type:'MY_ORDER_SUCCESS',
               payload:data
    
            })
           
        //     localStorage.removeItem("cartitems")
        //     toast.success("order placed")

    
        }
        catch(error){
    dispatch({type:'MY-ORDER_FAILED',
            payload:error.response && 
            error.response.data.message ? error.response.data.message:error.message})
    
        }
    }