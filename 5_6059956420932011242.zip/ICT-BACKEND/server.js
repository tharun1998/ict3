import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import colors from 'colors';
import userroutes from './Routes/UserRoutes.js'
import dotenv from 'dotenv';
import FavListRoutes from './Routes/Favlistroutes.js'
import ProductRoutes  from './Routes/ProductRoutes.js'
import Recommendedroutes from './Routes/Recommendationroutes.js'
const app=express();
app.use(express.json());
app.use(cors());

app.use("/users",userroutes);
app.use("/products",ProductRoutes);
app.use("/favlist",FavListRoutes);
app.use("/recommendedlist",Recommendedroutes)



mongoose.connect("mongodb://127.0.0.1:27017/ict",{ 
    useNewUrlParser:true,
    useUnifiedTopology:true
})
.then(()=>console.log('im connected to   database ' .underline.blue))
.catch(err=>console.log(`${err}`.underline.red ));


// app.get("/",async(req,res)=>{
//     res.status(200).json("yoo im being summoned tell me your wish, i shall grant you any data you wish")
// })


app.listen(8001 ,console.log(`Hi im up and Running good and running on `.blue))