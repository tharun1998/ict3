import mongoose from 'mongoose';


const Schema=mongoose.Schema;

const ReviewSchema = new Schema({

    Name:{
        type:String,
    
    },
    
    Comments:{
        type:String,
        
    
    },
    user:{
        type:mongoose.Schema.Types.ObjectId,
        required:true,
        ref:'User'
            },
     },
    {
        timestamps:true
    }
    
    )
    
const ProductSchema = new Schema({


Name:{
    type:String,
    

},
Author:{
    type:String
},
Img:{
    type:String,
    default:"https://picsum.photos/200"
},
Category:{
    type:String,

},
Language:{
    type:String,
},
Description:{
    type:String,

},
reviews:[ReviewSchema],
NumberofReviews:{
    type:Number,
}

},



{
    timestamps:true
}

)




const Product=mongoose.model("Product",ProductSchema);

export default Product;
