import jwt from 'jsonwebtoken';
const generatenewtoken=(id)=>{
return jwt.sign({id},"SAN3005",
    {expiresIn:'30d'})
}
export default generatenewtoken;