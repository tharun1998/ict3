import Product from '../models/Productmodel.js';
const getProducts=async(req,res)=>{
  const words=req.query.words ? {
    Name:{
$regex:req.query.words,
$options:'i',
    },
  }:{}
    const data=await Product.find({...words});
    // const data=await Product.find({});

      res.json(data);
}
const getProduct=async(req,res)=>{
    const data= await Product.findById(req.params.id);
    res.json(data);
}
 const bookreview=async(req,res)=>{
   const book= await Product.findById(req.params.id);
   if(book){
     const alreadyreviewed=book.revies.find((r)=>r.user.toString===req.user._id.toString())
     if(alreadyreviewed){
       res.status(400);
       throw new Error('book already reviewed')

     }
     const review={
       Name:req.user.Name,
       Comments,
       user:req.user._id

     }
     book.reviews.push(review)
     numReviews=book.reviews.length
     await book.save()
     res.status(201).json({message:'review added'})
   }
   else{
     re.status(404)
     throw new error('book not found')
   }
 }
 const newbook=async(req,res)=>{
  const book=await new Product({
    
      Name:req.body.Name,
      Author:req.body.Author,
      Category:req.body.Category,
      Language:req.body.Language,
      Description:req.body.Description,

  })
  book.save();
  res.json(book);


}

export{getProducts,getProduct,bookreview,newbook}