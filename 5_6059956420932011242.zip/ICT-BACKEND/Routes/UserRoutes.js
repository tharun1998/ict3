import express from 'express';
const router=express.Router();
import {Authenticatingusers  ,RegisteringUsers} from '../Controllers/usercontroller.js'
import {protectede} from '../middleware/Authentication.js'

router.post("/loginuser",Authenticatingusers)
router.post("/Registration",RegisteringUsers);
//admin routes

// /users/loginuser
export default router;