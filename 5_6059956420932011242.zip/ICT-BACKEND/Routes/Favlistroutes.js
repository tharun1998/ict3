import express from 'express';
const router=express.Router();
 import {creatingfavlist, myfavlist} from '../Controllers/FavListController.js'
import {protectede} from '../middleware/Authentication.js'

router.post("/",protectede,creatingfavlist)
router.get("/myfav",protectede,myfavlist)

export default router;